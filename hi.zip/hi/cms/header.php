<div  class="container">
        
        	<div class="col-md-9">
            <h1> <a href="<?php echo $HomeURL;?>"><img src="<?php echo $HomeURL;?>/images/nihfw-logo.jpg" class="img-responsive" title="National Institute of Health and Family Welfare" alt="National Institute of Health and Family Welfare"> <span class="hidethis">The National Institute of Health and Family Welfare (NIHFW)</span></a>
            </h1>
            </div>
            
            
            
            <div class="col-md-3 pull-right">
           
            <img src="<?php echo $HomeURL;?>/images/indian-emblem.jpg" alt="Indian Emblem" title="Indian Emblem" class="img-responsive">
            
            </div>
            
    	</div>